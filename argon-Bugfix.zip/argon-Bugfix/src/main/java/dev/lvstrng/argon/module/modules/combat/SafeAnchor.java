package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.BooleanSetting;
import dev.lvstrng.argon.module.setting.ModeSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.BlockUtils;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import dev.lvstrng.argon.utils.KeyUtils;
import dev.lvstrng.argon.utils.WorldUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.function.Predicate;

/**
 * SafeAnchor
 * <p>
 * Same trigger as {@link AnchorMacro} (hold right click while looking at a respawn anchor), but the explosion
 * is made safe for the user:
 * <ol>
 *     <li>charge the anchor with glowstone,</li>
 *     <li>place a solid "shield" block on the face of the anchor that points at you
 *         (explosion damage is scaled by how many rays from your hitbox reach the anchor, so a block in between
 *         removes most of the damage),</li>
 *     <li>explode the anchor from a free face using the explode slot, then optionally switch back.</li>
 * </ol>
 * The shield is NOT placed against the anchor itself: right-clicking a charged anchor with any item would
 * explode it (vanilla behaviour), so the block is placed against a neighbouring support block instead.
 * <p>
 * Note: respawn anchors do not explode in the Nether, so the module does nothing there.
 * Disable {@link AnchorMacro} while using this module, otherwise both will act on the same anchor.
 */
public final class SafeAnchor extends Module implements TickListener {
	public enum ShieldBlock {
		Obsidian, Glowstone, Any
	}

	/** Squared interaction range used for the anchor (vanilla survival reach is 4.5, server hard limit is 6). */
	private static final double REACH_SQ = 4.5 * 4.5;
	/** Ticks to wait for the server to remove an exploded anchor before we retry. */
	private static final int RETRY_TICKS = 10;

	private final ModeSetting<ShieldBlock> shieldBlock = new ModeSetting<>(EncryptedString.of("Shield Block"), ShieldBlock.Obsidian, ShieldBlock.class)
			.setDescription(EncryptedString.of("Block placed between you and the anchor"));
	private final BooleanSetting placeShield = new BooleanSetting(EncryptedString.of("Place Shield"), true)
			.setDescription(EncryptedString.of("Places the protective block before exploding"));
	private final BooleanSetting requireShield = new BooleanSetting(EncryptedString.of("Require Shield"), true)
			.setDescription(EncryptedString.of("Never explode unless the shield is in place (waits if it can't be placed)"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true)
			.setDescription(EncryptedString.of("Returns to your original slot after exploding"));
	private final NumberSetting delay = new NumberSetting(EncryptedString.of("Delay"), 0, 10, 0, 1)
			.setDescription(EncryptedString.of("Ticks between each step"));
	private final NumberSetting explodeSlot = new NumberSetting(EncryptedString.of("Explode Slot"), 1, 9, 1, 1)
			.setDescription(EncryptedString.of("Hotbar slot used to explode (must not hold glowstone)"));

	/** Anchor currently being handled, null when idle. */
	private BlockPos target;
	private boolean shielded;
	private boolean finished;
	private int finishedTicks;
	private int clock;
	private int originalSlot = -1;

	public SafeAnchor() {
		super(EncryptedString.of("Safe Anchor"),
				EncryptedString.of("Charges an anchor, shields yourself with a block, then explodes it"),
				-1,
				Category.COMBAT);
		addSettings(shieldBlock, placeShield, requireShield, switchBack, delay, explodeSlot);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		reset();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		reset();
		super.onDisable();
	}

	private void reset() {
		target = null;
		shielded = false;
		finished = false;
		finishedTicks = 0;
		clock = 0;
		originalSlot = -1;
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null)
			return;

		// Anchors only explode outside the Nether
		if (mc.world.getRegistryKey() == World.NETHER)
			return;

		if (!KeyUtils.isKeyPressed(GLFW.GLFW_MOUSE_BUTTON_RIGHT)) {
			reset();
			return;
		}

		// Acquire a target from the crosshair
		if (target == null) {
			if (mc.crosshairTarget instanceof BlockHitResult hit
					&& hit.getType() == HitResult.Type.BLOCK
					&& BlockUtils.isBlock(hit.getBlockPos(), Blocks.RESPAWN_ANCHOR)) {
				target = hit.getBlockPos().toImmutable();
				originalSlot = mc.player.getInventory().selectedSlot;
			} else return;
		}

		// Anchor is gone (exploded / broken): cycle done
		if (!BlockUtils.isBlock(target, Blocks.RESPAWN_ANCHOR)) {
			reset();
			return;
		}

		// Out of reach: abort
		if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(target)) > REACH_SQ) {
			reset();
			return;
		}

		// Stop vanilla from also using the item this tick
		mc.options.useKey.setPressed(false);

		// Waiting for the server to confirm the explosion
		if (finished) {
			if (++finishedTicks > RETRY_TICKS) {
				finished = false;
				finishedTicks = 0;
			}
			return;
		}

		if (clock < delay.getValueInt()) {
			clock++;
			return;
		}

		BlockState state = mc.world.getBlockState(target);

		// Step 1: charge
		if (state.get(RespawnAnchorBlock.CHARGES) == 0) {
			if (!InventoryUtils.selectItemFromHotbar(Items.GLOWSTONE))
				return;

			WorldUtils.placeBlock(anchorHit(), true);
			clock = 0;
			return;
		}

		// Step 2: shield
		if (placeShield.getValue() && !shielded) {
			if (handleShield()) {
				clock = 0;
				return; // one action per step, explode on a later tick
			}

			// shield could not be handled; stop here unless the user allows exploding without it
			if (requireShield.getValue())
				return;
		}

		// Step 3: explode
		explode();
	}

	/**
	 * Tries to make sure a solid block sits between the anchor and the player.
	 *
	 * @return true if an action was performed this tick (placed, or detected an existing block), false if the
	 * shield is currently impossible (no block in hotbar, no support, entity in the way).
	 */
	private boolean handleShield() {
		// Side of the anchor that faces the player
		Vec3d toPlayer = mc.player.getEyePos().subtract(Vec3d.ofCenter(target));
		Direction side = Direction.getFacing(toPlayer.x, toPlayer.y, toPlayer.z);
		BlockPos shieldPos = target.offset(side);

		BlockState current = mc.world.getBlockState(shieldPos);

		// Already something solid in the way (wall, previously placed shield, ...)
		if (current.isSolidBlock(mc.world, shieldPos)) {
			shielded = true;
			return true;
		}

		if (!current.isReplaceable())
			return false;

		// Don't try to place into an entity (e.g. ourselves when standing right next to the anchor)
		Box box = new Box(shieldPos);
		if (!mc.world.getOtherEntities(null, box, e -> !e.isSpectator() && !(e instanceof ItemEntity)).isEmpty())
			return false;

		BlockHitResult placeHit = supportHit(shieldPos);
		if (placeHit == null)
			return false;

		if (!InventoryUtils.selectItemFromHotbar(shieldPredicate()))
			return false;

		WorldUtils.placeBlock(placeHit, true);
		shielded = true;
		return true;
	}

	/** Explodes the anchor using the explode slot. */
	private void explode() {
		int slot = explodeSlot.getValueInt() - 1;

		// A glowstone in either hand would charge / pass through instead of exploding (vanilla rule)
		if (mc.player.getInventory().getStack(slot).isOf(Items.GLOWSTONE) || mc.player.getOffHandStack().isOf(Items.GLOWSTONE))
			return;

		if (mc.player.getInventory().selectedSlot != slot)
			InventoryUtils.setInvSlot(slot);

		WorldUtils.placeBlock(anchorHit(), true);

		if (switchBack.getValue() && originalSlot != -1 && originalSlot != slot)
			InventoryUtils.setInvSlot(originalSlot);

		finished = true;
		finishedTicks = 0;
		clock = 0;
	}

	/** Hit on the target anchor: the crosshair hit if it's on the anchor, otherwise a computed exposed face. */
	private BlockHitResult anchorHit() {
		if (mc.crosshairTarget instanceof BlockHitResult hit
				&& hit.getType() == HitResult.Type.BLOCK
				&& hit.getBlockPos().equals(target))
			return hit;

		return faceHit(target, bestFace(target));
	}

	/** Face of the block closest to the player that isn't covered by a solid neighbour. */
	private Direction bestFace(BlockPos pos) {
		Vec3d eye = mc.player.getEyePos();
		Direction best = Direction.UP;
		double bestDist = Double.MAX_VALUE;

		for (Direction dir : Direction.values()) {
			BlockPos neighbour = pos.offset(dir);
			if (mc.world.getBlockState(neighbour).isSolidBlock(mc.world, neighbour))
				continue;

			double dist = eye.squaredDistanceTo(faceCenter(pos, dir));
			if (dist < bestDist) {
				bestDist = dist;
				best = dir;
			}
		}

		return best;
	}

	/**
	 * Finds a support block next to {@code placePos} (never the anchor itself) and builds the hit result that
	 * places a block at {@code placePos}. Floor is preferred, then walls, then ceiling.
	 */
	private BlockHitResult supportHit(BlockPos placePos) {
		Direction[] order = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};

		for (Direction dir : order) {
			BlockPos support = placePos.offset(dir);

			if (support.equals(target))
				continue;

			BlockState supportState = mc.world.getBlockState(support);
			if (!supportState.isSolidBlock(mc.world, support) || !isSafeSupport(supportState.getBlock()))
				continue;

			// The face of the support that points at the placement position
			return faceHit(support, dir.getOpposite());
		}

		return null;
	}

	/** Blocks that react to a right click and would therefore swallow our placement click. */
	private static boolean isSafeSupport(Block block) {
		if (block instanceof BlockEntityProvider || block == Blocks.RESPAWN_ANCHOR || block == Blocks.CRAFTING_TABLE)
			return false;

		return !(block.getDefaultState().isIn(BlockTags.ANVIL)
				|| block.getDefaultState().isIn(BlockTags.DOORS)
				|| block.getDefaultState().isIn(BlockTags.TRAPDOORS)
				|| block.getDefaultState().isIn(BlockTags.BUTTONS)
				|| block.getDefaultState().isIn(BlockTags.FENCE_GATES)
				|| block.getDefaultState().isIn(BlockTags.BEDS));
	}

	private Predicate<Item> shieldPredicate() {
		return switch (shieldBlock.getMode()) {
			case Obsidian -> item -> item == Items.OBSIDIAN || item == Items.CRYING_OBSIDIAN;
			case Glowstone -> item -> item == Items.GLOWSTONE;
			case Any -> item -> {
				if (!(item instanceof BlockItem blockItem))
					return false;

				Block block = blockItem.getBlock();
				// keep glowstone for charging; skip blocks that fall, have GUIs or explode
				return block != Blocks.GLOWSTONE
						&& block != Blocks.RESPAWN_ANCHOR
						&& block != Blocks.TNT
						&& !(block instanceof FallingBlock)
						&& !(block instanceof BlockEntityProvider);
			};
		};
	}

	private static Vec3d faceCenter(BlockPos pos, Direction face) {
		return Vec3d.ofCenter(pos).add(Vec3d.of(face.getVector()).multiply(0.5));
	}

	private static BlockHitResult faceHit(BlockPos pos, Direction face) {
		return new BlockHitResult(faceCenter(pos, face), face, pos, false);
	}
}
