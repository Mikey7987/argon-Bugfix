package dev.lvstrng.argon.module.modules.combat;

import dev.lvstrng.argon.event.events.TickListener;
import dev.lvstrng.argon.module.Category;
import dev.lvstrng.argon.module.Module;
import dev.lvstrng.argon.module.setting.KeybindSetting;
import dev.lvstrng.argon.module.setting.NumberSetting;
import dev.lvstrng.argon.utils.DamageUtils;
import dev.lvstrng.argon.utils.EncryptedString;
import dev.lvstrng.argon.utils.InventoryUtils;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * One-key anchor sequence. The activation key starts a short, tick-driven
 * sequence: place an anchor, charge it once, place glowstone behind it, then
 * use the configured hotbar slot to attempt detonation. The interaction mixin
 * retains the lethal-self-damage guard.
 */
public final class SafeAnchoring extends Module implements TickListener {
    private final KeybindSetting activateKey = new KeybindSetting(
            EncryptedString.of("Activate Key"), GLFW.GLFW_KEY_N, false
    ).setDescription(EncryptedString.of("Key that starts the safe-anchor sequence"));
    private final NumberSetting explodeSlot = new NumberSetting(
            EncryptedString.of("Explode Slot"), 1, 9, 1, 1
    ).setDescription(EncryptedString.of("Hotbar slot used for the final anchor interaction (1-9)"));
    private final NumberSetting aimDown = new NumberSetting(
            EncryptedString.of("Aim Down"), 0, 20, 8, 1
    ).setDescription(EncryptedString.of("Degrees to aim down briefly while placing the rear glowstone"));
    private final NumberSetting healthBuffer = new NumberSetting(
            EncryptedString.of("Health Buffer"), 0, 10, 1, 0.5
    ).setDescription(EncryptedString.of("Blocks the final interaction when predicted damage is lethal or too close to lethal"));

    private int step;
    private boolean keyWasDown;
    private int waitTicks;
    private BlockHitResult initialHit;
    private BlockPos anchorPos;
    private BlockPos rearGlowstonePos;
    private float originalYaw;
    private float originalPitch;
    private boolean changedRotation;

    public SafeAnchoring() {
        super(
                EncryptedString.of("Safe Anchoring"),
                EncryptedString.of("Runs a one-key anchor, charge, rear-glowstone and explode-slot sequence"),
                -1,
                Category.COMBAT
        );
        addSettings(activateKey, explodeSlot, aimDown, healthBuffer);
    }

    @Override
    public void onEnable() {
        eventManager.add(TickListener.class, this);
        resetSequence();
        keyWasDown = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(TickListener.class, this);
        restoreRotation();
        resetSequence();
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getWindow() == null) {
            resetSequence();
            return;
        }

        boolean keyDown = activateKey.getKey() >= 0
                && GLFW.glfwGetKey(mc.getWindow().getHandle(), activateKey.getKey()) == GLFW.GLFW_PRESS;
        if (mc.currentScreen == null && keyDown && !keyWasDown && step == 0) {
            beginSequence();
        }
        keyWasDown = keyDown;

        if (step == 0 || mc.currentScreen != null) return;
        if (waitTicks > 0) {
            waitTicks--;
            return;
        }

        switch (step) {
            case 1 -> placeAnchor();
            case 2 -> chargeAnchorOnce();
            case 3 -> placeRearGlowstone();
            case 4 -> detonateFromSelectedSlot();
            default -> resetSequence();
        }
    }

    private void beginSequence() {
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        if (!InventoryUtils.hasItemInHotbar(item -> item == Items.RESPAWN_ANCHOR)
                || !InventoryUtils.hasItemInHotbar(item -> item == Items.GLOWSTONE)) return;

        initialHit = hit;
        BlockPos clicked = hit.getBlockPos();
        BlockPos placementPos = clicked.offset(hit.getSide());
        if (mc.world.getBlockState(placementPos).isReplaceable()) {
            anchorPos = placementPos;
        } else if (mc.world.getBlockState(clicked).isReplaceable()) {
            anchorPos = clicked;
        } else {
            return;
        }
        step = 1;
        waitTicks = 0;
    }

    private void placeAnchor() {
        if (!mc.world.getBlockState(anchorPos).isOf(Blocks.RESPAWN_ANCHOR)) {
            if (!InventoryUtils.selectItemFromHotbar(Items.RESPAWN_ANCHOR)) {
                resetSequence();
                return;
            }
            WorldPlace.place(mc.player.getMainHandStack(), initialHit);
            waitTicks = 1;
            step = 2;
            return;
        }
        step = 2;
    }

    private void chargeAnchorOnce() {
        BlockState state = mc.world.getBlockState(anchorPos);
        if (!state.isOf(Blocks.RESPAWN_ANCHOR)) {
            resetSequence();
            return;
        }
        if (state.contains(RespawnAnchorBlock.CHARGES) && state.get(RespawnAnchorBlock.CHARGES) > 0) {
            calculateRearPosition();
            step = 3;
            return;
        }
        if (!InventoryUtils.selectItemFromHotbar(Items.GLOWSTONE)) {
            resetSequence();
            return;
        }
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, anchorHit());
        mc.player.swingHand(Hand.MAIN_HAND);
        waitTicks = 1;
        // Stay on this step until the client world confirms the single charge.
    }

    private void calculateRearPosition() {
        Vec3d playerPos = mc.player.getPos();
        double dx = playerPos.x - (anchorPos.getX() + 0.5);
        double dz = playerPos.z - (anchorPos.getZ() + 0.5);
        Direction towardPlayer = Math.abs(dx) > Math.abs(dz)
                ? (dx >= 0 ? Direction.EAST : Direction.WEST)
                : (dz >= 0 ? Direction.SOUTH : Direction.NORTH);
        // Put the opaque glowstone block on the player-facing side of the anchor
        // so it can reduce exposure to the blast.
        rearGlowstonePos = anchorPos.offset(towardPlayer);
    }

    private void placeRearGlowstone() {
        if (rearGlowstonePos == null) {
            resetSequence();
            return;
        }
        if (!mc.world.getBlockState(rearGlowstonePos).isReplaceable()) {
            // There is no free cell behind the anchor; do not place into an unrelated block.
            step = 4;
            return;
        }
        if (!InventoryUtils.selectItemFromHotbar(Items.GLOWSTONE)) {
            resetSequence();
            return;
        }

        // Place against a solid block behind the target cell, clicking its face
        // toward the anchor. If no valid support exists, skip this optional step.
        Direction away = directionFromAnchorTo(rearGlowstonePos);
        BlockPos supportPos = rearGlowstonePos.offset(away);
        BlockState support = mc.world.getBlockState(supportPos);
        if (!support.isSideSolidFullSquare(mc.world, supportPos, away.getOpposite())) {
            step = 4;
            return;
        }

        originalYaw = mc.player.getYaw();
        originalPitch = mc.player.getPitch();
        changedRotation = true;
        mc.player.setPitch(MathHelper.clamp(originalPitch + aimDown.getValueFloat(), -90.0F, 90.0F));
        BlockHitResult supportHit = new BlockHitResult(
                Vec3d.ofCenter(supportPos), away.getOpposite(), supportPos, false
        );
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, supportHit);
        mc.player.swingHand(Hand.MAIN_HAND);
        waitTicks = 1;
        step = 4;
    }

    private Direction directionFromAnchorTo(BlockPos pos) {
        int dx = pos.getX() - anchorPos.getX();
        int dz = pos.getZ() - anchorPos.getZ();
        if (Math.abs(dx) > Math.abs(dz)) return dx >= 0 ? Direction.EAST : Direction.WEST;
        return dz >= 0 ? Direction.SOUTH : Direction.NORTH;
    }

    private void detonateFromSelectedSlot() {
        BlockState state = mc.world.getBlockState(anchorPos);
        if (!state.isOf(Blocks.RESPAWN_ANCHOR)
                || !state.contains(RespawnAnchorBlock.CHARGES)
                || state.get(RespawnAnchorBlock.CHARGES) <= 0) {
            restoreRotation();
            resetSequence();
            return;
        }

        int slot = explodeSlot.getValueInt() - 1;
        InventoryUtils.setInvSlot(slot);
        ItemStack stack = mc.player.getMainHandStack();
        if (stack.isOf(Items.GLOWSTONE) || stack.isOf(Items.RESPAWN_ANCHOR)) {
            // These items would charge or attempt to place an anchor instead of
            // reliably acting as the selected detonation item.
            restoreRotation();
            resetSequence();
            return;
        }
        if (shouldBlockDetonation(mc.player, anchorHit(), stack)) {
            // Keep the existing self-damage protection: never knowingly continue
            // with a predicted lethal final interaction.
            restoreRotation();
            resetSequence();
            return;
        }
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, anchorHit());
        mc.player.swingHand(Hand.MAIN_HAND);
        restoreRotation();
        resetSequence();
    }

    private BlockHitResult anchorHit() {
        return new BlockHitResult(Vec3d.ofCenter(anchorPos), Direction.UP, anchorPos, false);
    }

    private void restoreRotation() {
        if (changedRotation && mc.player != null) {
            mc.player.setYaw(originalYaw);
            mc.player.setPitch(originalPitch);
        }
        changedRotation = false;
    }

    private void resetSequence() {
        step = 0;
        waitTicks = 0;
        initialHit = null;
        anchorPos = null;
        rearGlowstonePos = null;
    }

    /** Used by the interaction mixin to keep manual and macro detonations safe. */
    public boolean shouldBlockDetonation(net.minecraft.client.network.ClientPlayerEntity player,
                                         BlockHitResult hit, ItemStack stack) {
        if (!isEnabled() || player == null || mc.world == null || hit == null || stack == null) return false;
        BlockState state = mc.world.getBlockState(hit.getBlockPos());
        if (!state.isOf(Blocks.RESPAWN_ANCHOR) || stack.isOf(Items.GLOWSTONE)
                || !state.contains(RespawnAnchorBlock.CHARGES)
                || state.get(RespawnAnchorBlock.CHARGES) <= 0) return false;

        float predictedDamage;
        try {
            predictedDamage = DamageUtils.anchorDamage(player, Vec3d.ofCenter(hit.getBlockPos()));
        } catch (RuntimeException exception) {
            return true;
        }
        if (!Float.isFinite(predictedDamage)) return true;
        float effectiveHealth = player.getHealth() + player.getAbsorptionAmount();
        double threshold = Math.max(0.0, effectiveHealth - healthBuffer.getValue());
        return predictedDamage >= threshold;
    }

    /** Small wrapper keeps the place interaction consistent with the project's utility usage. */
    private static final class WorldPlace {
        private static void place(ItemStack stack, BlockHitResult hit) {
            if (stack != null && !stack.isEmpty()) {
                dev.lvstrng.argon.Argon.mc.interactionManager.interactBlock(
                        dev.lvstrng.argon.Argon.mc.player, Hand.MAIN_HAND, hit
                );
                dev.lvstrng.argon.Argon.mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}
