package dev.lvstrng.argon.mixin;

import dev.lvstrng.argon.Argon;
import dev.lvstrng.argon.module.modules.combat.SafeAnchoring;
import dev.lvstrng.argon.module.modules.misc.NoBreakDelay;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
    @Shadow
    private int blockBreakingCooldown;

    @Redirect(method = "updateBlockBreakingProgress",
            at = @At(value = "FIELD", target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;blockBreakingCooldown:I", opcode = Opcodes.GETFIELD, ordinal = 0))
    public int updateBlockBreakingProgress(ClientPlayerInteractionManager clientPlayerInteractionManager) {
        int cooldown = this.blockBreakingCooldown;
        return Argon.INSTANCE.getModuleManager().getModule(NoBreakDelay.class).isEnabled() ? 0 : cooldown;
    }

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void argon$guardLethalAnchor(
            ClientPlayerEntity player,
            Hand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        if (Argon.INSTANCE == null || Argon.INSTANCE.getModuleManager() == null || player == null) {
            return;
        }

        SafeAnchoring module = Argon.INSTANCE.getModuleManager().getModule(SafeAnchoring.class);
        if (module == null || !module.isEnabled()) {
            return;
        }

        ItemStack stack = player.getStackInHand(hand);
        if (module.shouldBlockDetonation(player, hitResult, stack)) {
            cir.setReturnValue(ActionResult.FAIL);
        }
    }
}
